function buscador(){
    filter=inputSearch.value.toUpperCase();
}